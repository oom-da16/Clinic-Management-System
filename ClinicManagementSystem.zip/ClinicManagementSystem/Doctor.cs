// ============================================================
//  File: Doctor.cs
//  Description: Doctor class – inherits from Person
// ============================================================

using System;

namespace ClinicManagementSystem
{
    /// <summary>
    /// Represents a doctor registered in the clinic.
    /// Inherits common personal information from Person.
    /// </summary>
    public class Doctor : Person
    {
        // ── Doctor-specific properties ───────────────────────────────
        public Specialization Specialization { get; set; }
        public string         LicenseNumber  { get; set; }
        public string         WorkingDays    { get; set; }   // e.g. "Mon,Tue,Wed"
        public decimal        ConsultationFee { get; set; }

        // ── Constructor ─────────────────────────────────────────────
        public Doctor(string id, string fullName, Gender gender,
                      DateTime dateOfBirth, string phone,
                      Specialization specialization, string licenseNumber,
                      string workingDays, decimal consultationFee)
            : base(id, fullName, gender, dateOfBirth, phone)
        {
            Specialization  = specialization;
            LicenseNumber   = licenseNumber;
            WorkingDays     = workingDays;
            ConsultationFee = consultationFee;
        }

        // ── POLYMORPHISM – override abstract method ──────────────────
        public override string GetDetails()
        {
            return $"Doctor ID      : {ID}\n" +
                   $"Name           : Dr. {FullName}\n" +
                   $"Specialization : {Specialization}\n" +
                   $"License No.    : {LicenseNumber}\n" +
                   $"Phone          : {Phone}\n" +
                   $"Working Days   : {WorkingDays}\n" +
                   $"Consult. Fee   : {ConsultationFee:C}";
        }

        // ── Override ToString ─────────────────────────────────────────
        public override string ToString() => $"Dr. {FullName} ({Specialization})";

        // ── FILE HANDLING – serialise to CSV line ───────────────────
        public override string ToFileLine()
        {
            // Format: D|ID|FullName|Gender|DOB|Phone|Specialization|License|WorkingDays|Fee
            return $"D|{ID}|{FullName}|{(int)Gender}|{DateOfBirth:yyyy-MM-dd}|" +
                   $"{Phone}|{(int)Specialization}|{LicenseNumber}|{WorkingDays}|{ConsultationFee}";
        }

        // ── Deserialise from CSV line ────────────────────────────────
        public static Doctor FromFileLine(string line)
        {
            string[] p = line.Split('|');
            return new Doctor(
                id:             p[1],
                fullName:       p[2],
                gender:         (Gender)int.Parse(p[3]),
                dateOfBirth:    DateTime.Parse(p[4]),
                phone:          p[5],
                specialization: (Specialization)int.Parse(p[6]),
                licenseNumber:  p[7],
                workingDays:    p[8],
                consultationFee: decimal.Parse(p[9])
            );
        }
    }
}

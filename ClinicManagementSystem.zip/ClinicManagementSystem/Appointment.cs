// ============================================================
//  File: Appointment.cs
//  Description: Appointment class – links Patient and Doctor
// ============================================================

using System;

namespace ClinicManagementSystem
{
    /// <summary>
    /// Represents a scheduled appointment between a patient and a doctor.
    /// Demonstrates CLASS DEFINITIONS, ENUMERATIONS, and FILE HANDLING.
    /// </summary>
    public class Appointment
    {
        // ── Properties ──────────────────────────────────────────────
        public string            AppointmentID { get; set; }
        public string            PatientID     { get; set; }
        public string            DoctorID      { get; set; }
        public DateTime          DateTime      { get; set; }
        public AppointmentStatus Status        { get; set; }
        public string            Notes         { get; set; }

        // ── Constructor ─────────────────────────────────────────────
        public Appointment(string appointmentID, string patientID, string doctorID,
                           DateTime dateTime, AppointmentStatus status, string notes = "")
        {
            AppointmentID = appointmentID;
            PatientID     = patientID;
            DoctorID      = doctorID;
            DateTime      = dateTime;
            Status        = status;
            Notes         = notes;
        }

        // ── Display summary ──────────────────────────────────────────
        public string GetDetails()
        {
            return $"Appointment ID : {AppointmentID}\n" +
                   $"Patient ID     : {PatientID}\n" +
                   $"Doctor ID      : {DoctorID}\n" +
                   $"Date & Time    : {DateTime:dd/MM/yyyy HH:mm}\n" +
                   $"Status         : {Status}\n" +
                   $"Notes          : {(string.IsNullOrEmpty(Notes) ? "—" : Notes)}";
        }

        public override string ToString()
            => $"{AppointmentID} | {DateTime:dd/MM/yyyy HH:mm} | {Status}";

        // ── FILE HANDLING ────────────────────────────────────────────
        public string ToFileLine()
        {
            // Format: AppID|PatID|DocID|DateTime|Status|Notes
            return $"{AppointmentID}|{PatientID}|{DoctorID}|" +
                   $"{DateTime:yyyy-MM-dd HH:mm}|{(int)Status}|{Notes}";
        }

        public static Appointment FromFileLine(string line)
        {
            string[] p = line.Split('|');
            return new Appointment(
                appointmentID: p[0],
                patientID:     p[1],
                doctorID:      p[2],
                dateTime:      System.DateTime.Parse(p[3]),
                status:        (AppointmentStatus)int.Parse(p[4]),
                notes:         p.Length > 5 ? p[5] : ""
            );
        }
    }
}

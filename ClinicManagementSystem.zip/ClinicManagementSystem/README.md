# Clinic Management System
## CSE015 — Object-Oriented Programming | Spring 2026
### New Mansoura University — Faculty of CS and Engineering

---

## Project Overview

A Windows Forms desktop application built in C# for managing a medical clinic.
Covers all 5 required OOP concepts plus 2 bonus concepts:

| OOP Concept        | Where it's used                                            |
|--------------------|------------------------------------------------------------|
| Class Definitions  | Person, Patient, Doctor, Appointment, MedicalRecord, Clinic |
| Array of Objects   | Patient[], Doctor[], Appointment[], MedicalRecord[] in Clinic.cs |
| Inheritance        | Patient and Doctor both inherit from abstract Person        |
| Enumerations       | AppointmentStatus, Gender, BloodType, Specialization       |
| File Handling      | FileManager.cs — StreamWriter/File.ReadAllLines for .txt files |
| Polymorphism ✓     | GetDetails() overridden in Patient and Doctor              |
| Exception Handling ✓ | Try/catch throughout all forms and FileManager.cs        |

---

## Project Structure

```
ClinicManagementSystem/
│
├── Enums.cs              — All enumerations
├── Person.cs             — Abstract base class (INHERITANCE root)
├── Patient.cs            — Inherits Person
├── Doctor.cs             — Inherits Person
├── Appointment.cs        — Links Patient + Doctor + Status
├── MedicalRecord.cs      — Diagnosis/Prescription per visit
├── Clinic.cs             — Data store with ARRAYS OF OBJECTS + Singleton
├── FileManager.cs        — FILE HANDLING + EXCEPTION HANDLING
├── FormDashboard.cs      — Main window + statistics overview
├── FormPatients.cs       — Patient management UI
├── FormDoctors.cs        — Doctor management UI
├── FormAppointments.cs   — Appointment scheduling UI
├── FormRecords.cs        — Medical records UI
├── Program.cs            — Application entry point
└── ClinicManagementSystem.csproj
```

---

## How to Build & Run

### Prerequisites
- Visual Studio 2022 (Community edition is free)
- .NET 6.0 SDK or later (included with VS2022)

### Steps
1. Open **Visual Studio 2022**
2. Click **"Open a project or solution"**
3. Navigate to the `ClinicManagementSystem/` folder
4. Select `ClinicManagementSystem.csproj`
5. Press **F5** to build and run

### Data Storage
When the application runs, it automatically creates a `ClinicData/` folder
next to the executable containing:
- `patients.txt`
- `doctors.txt`
- `appointments.txt`
- `records.txt`
- `error.log` (only created on errors)

---

## Team Responsibilities (suggested)

| Student | Module                                      |
|---------|---------------------------------------------|
| 1       | Patient.cs + FormPatients.cs                |
| 2       | Doctor.cs + FormDoctors.cs                  |
| 3       | Appointment.cs + FormAppointments.cs        |
| 4       | MedicalRecord.cs + FormRecords.cs           |
| 5       | Clinic.cs + FileManager.cs + Program.cs     |
| 6       | FormDashboard.cs + integration + testing    |

---

## AI Assistance Disclosure
This project structure and initial code were generated with AI assistance (Claude by Anthropic).
All code must be reviewed, understood, and modified by the team to reflect your own approach.
Please cite this assistance in your documentation and code comments as required by the Honor Code.

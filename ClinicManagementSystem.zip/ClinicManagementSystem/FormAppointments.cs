// ============================================================
//  File: FormAppointments.cs
//  Description: Appointment scheduling and status management
// ============================================================

using System;
using System.Drawing;
using System.Windows.Forms;

namespace ClinicManagementSystem
{
    public class FormAppointments : Form
    {
        private ListBox      lstAppointments;
        private ComboBox     cboPatient, cboDoctor, cboStatus;
        private DateTimePicker dtpDateTime;
        private TextBox      txtNotes;
        private Button       btnBook, btnUpdateStatus, btnClose;
        private Label        lblTitle;
        private Panel        panelForm, panelList;

        public FormAppointments()
        {
            InitializeComponent();
            LoadDropDowns();
            LoadAppointmentList();
        }

        private void InitializeComponent()
        {
            this.Text            = "Appointment Management";
            this.Size            = new Size(900, 600);
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox     = false;
            this.BackColor       = Color.WhiteSmoke;

            lblTitle = new Label
            {
                Text = "Appointment Scheduling", Font = new Font("Segoe UI", 16, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 60, 100), Location = new Point(10, 10), Size = new Size(450, 35)
            };

            panelList = new Panel { Location = new Point(10, 55), Size = new Size(350, 500) };
            lstAppointments = new ListBox { Dock = DockStyle.Fill, Font = new Font("Consolas", 9), BackColor = Color.White };
            lstAppointments.SelectedIndexChanged += Lst_SelectedIndexChanged;
            panelList.Controls.Add(lstAppointments);

            panelForm = new Panel { Location = new Point(370, 55), Size = new Size(510, 500), BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle };

            int y = 15; int labelW = 130; int rowH = 42;
            Func<string, int, Label> lbl = (t, top) => new Label { Text = t, Location = new Point(10, top + 3), Size = new Size(labelW, 24), Font = new Font("Segoe UI", 10) };

            cboPatient = new ComboBox { Location = new Point(145, y), Size = new Size(340, 25), Font = new Font("Segoe UI", 10), DropDownStyle = ComboBoxStyle.DropDownList };
            panelForm.Controls.Add(lbl("Patient:", y)); panelForm.Controls.Add(cboPatient); y += rowH;

            cboDoctor = new ComboBox { Location = new Point(145, y), Size = new Size(340, 25), Font = new Font("Segoe UI", 10), DropDownStyle = ComboBoxStyle.DropDownList };
            panelForm.Controls.Add(lbl("Doctor:", y)); panelForm.Controls.Add(cboDoctor); y += rowH;

            dtpDateTime = new DateTimePicker { Location = new Point(145, y), Size = new Size(260, 25), Font = new Font("Segoe UI", 10), Format = DateTimePickerFormat.Custom, CustomFormat = "dd/MM/yyyy  HH:mm", ShowUpDown = false };
            dtpDateTime.Value = DateTime.Now.AddDays(1);
            panelForm.Controls.Add(lbl("Date & Time:", y)); panelForm.Controls.Add(dtpDateTime); y += rowH;

            cboStatus = new ComboBox { Location = new Point(145, y), Size = new Size(180, 25), Font = new Font("Segoe UI", 10), DropDownStyle = ComboBoxStyle.DropDownList };
            cboStatus.Items.AddRange(Enum.GetNames(typeof(AppointmentStatus)));
            cboStatus.SelectedIndex = 0;
            panelForm.Controls.Add(lbl("Status:", y)); panelForm.Controls.Add(cboStatus); y += rowH;

            txtNotes = new TextBox { Location = new Point(145, y), Size = new Size(340, 60), Font = new Font("Segoe UI", 10), Multiline = true };
            panelForm.Controls.Add(lbl("Notes:", y)); panelForm.Controls.Add(txtNotes); y += 70;

            btnBook = new Button
            {
                Text = "📅 Book Appointment", Location = new Point(10, y), Size = new Size(200, 40),
                BackColor = Color.FromArgb(30, 130, 76), ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold), FlatStyle = FlatStyle.Flat
            };
            btnBook.Click += BtnBook_Click;

            btnUpdateStatus = new Button
            {
                Text = "🔄 Update Status", Location = new Point(220, y), Size = new Size(180, 40),
                BackColor = Color.FromArgb(30, 60, 100), ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold), FlatStyle = FlatStyle.Flat
            };
            btnUpdateStatus.Click += BtnUpdateStatus_Click;

            panelForm.Controls.AddRange(new Control[] { btnBook, btnUpdateStatus });

            btnClose = new Button
            {
                Text = "Close", Location = new Point(780, 540), Size = new Size(90, 32),
                BackColor = Color.Gray, ForeColor = Color.White,
                Font = new Font("Segoe UI", 10), FlatStyle = FlatStyle.Flat
            };
            btnClose.Click += (s, e) => this.Close();

            this.Controls.AddRange(new Control[] { lblTitle, panelList, panelForm, btnClose });
        }

        private void LoadDropDowns()
        {
            cboPatient.Items.Clear();
            cboDoctor.Items.Clear();
            foreach (var p in Clinic.Instance.GetAllPatients()) cboPatient.Items.Add(p);
            foreach (var d in Clinic.Instance.GetAllDoctors())  cboDoctor.Items.Add(d);
            if (cboPatient.Items.Count > 0) cboPatient.SelectedIndex = 0;
            if (cboDoctor.Items.Count  > 0) cboDoctor.SelectedIndex  = 0;
        }

        private void LoadAppointmentList()
        {
            lstAppointments.Items.Clear();
            foreach (var a in Clinic.Instance.GetAllAppointments())
            {
                var p = Clinic.Instance.FindPatientByID(a.PatientID);
                var d = Clinic.Instance.FindDoctorByID(a.DoctorID);
                lstAppointments.Items.Add(
                    $"{a.DateTime:dd/MM HH:mm} | {p?.FullName ?? a.PatientID} | {d?.FullName ?? a.DoctorID} | {a.Status}");
            }
        }

        private void Lst_SelectedIndexChanged(object sender, EventArgs e)
        {
            int idx = lstAppointments.SelectedIndex;
            if (idx < 0) return;
            var appointments = Clinic.Instance.GetAllAppointments();
            if (idx < appointments.Length)
            {
                var a = appointments[idx];
                dtpDateTime.Value = a.DateTime;
                cboStatus.SelectedIndex = (int)a.Status;
                txtNotes.Text = a.Notes;
            }
        }

        private void BtnBook_Click(object sender, EventArgs e)
        {
            try
            {
                if (cboPatient.SelectedItem == null) throw new ArgumentException("Please select a patient.");
                if (cboDoctor.SelectedItem  == null) throw new ArgumentException("Please select a doctor.");
                if (dtpDateTime.Value < DateTime.Now) throw new ArgumentException("Appointment date must be in the future.");

                var patient = (Patient)cboPatient.SelectedItem;
                var doctor  = (Doctor)cboDoctor.SelectedItem;

                var appt = new Appointment(
                    appointmentID: Clinic.Instance.GenerateAppointmentID(),
                    patientID:     patient.ID,
                    doctorID:      doctor.ID,
                    dateTime:      dtpDateTime.Value,
                    status:        AppointmentStatus.Pending,
                    notes:         txtNotes.Text.Trim()
                );

                Clinic.Instance.AddAppointment(appt);
                LoadAppointmentList();
                txtNotes.Clear();
                MessageBox.Show("Appointment booked successfully!", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (ArgumentException ex) { MessageBox.Show(ex.Message, "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            catch (Exception         ex) { MessageBox.Show(ex.Message, "Error",            MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void BtnUpdateStatus_Click(object sender, EventArgs e)
        {
            int idx = lstAppointments.SelectedIndex;
            if (idx < 0) { MessageBox.Show("Please select an appointment.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            var appointments = Clinic.Instance.GetAllAppointments();
            if (idx < appointments.Length)
            {
                var a = appointments[idx];
                Clinic.Instance.UpdateAppointmentStatus(a.AppointmentID, (AppointmentStatus)cboStatus.SelectedIndex);
                LoadAppointmentList();
                MessageBox.Show("Status updated!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}

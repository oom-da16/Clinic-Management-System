// ============================================================
//  File: FormPatients.cs
//  Description: Patient registration and management UI
// ============================================================

using System;
using System.Drawing;
using System.Windows.Forms;

namespace ClinicManagementSystem
{
    public class FormPatients : Form
    {
        private ListBox   lstPatients;
        private TextBox   txtID, txtName, txtPhone, txtAddress, txtAllergies;
        private ComboBox  cboGender, cboBlood;
        private DateTimePicker dtpDOB;
        private Button    btnAdd, btnRemove, btnDetails, btnClose;
        private Label     lblTitle;
        private Panel     panelForm, panelList;

        public FormPatients()
        {
            InitializeComponent();
            LoadPatientList();
        }

        private void InitializeComponent()
        {
            this.Text            = "Patient Management";
            this.Size            = new Size(860, 580);
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox     = false;
            this.BackColor       = Color.WhiteSmoke;

            lblTitle = new Label
            {
                Text      = "Patient Registration",
                Font      = new Font("Segoe UI", 16, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 60, 100),
                Location  = new Point(10, 10),
                Size      = new Size(400, 35)
            };

            // ── Left panel – list ────────────────────────────────────
            panelList = new Panel { Location = new Point(10, 55), Size = new Size(280, 480) };

            lstPatients = new ListBox
            {
                Dock      = DockStyle.Fill,
                Font      = new Font("Consolas", 10),
                BackColor = Color.White
            };
            lstPatients.SelectedIndexChanged += LstPatients_SelectedIndexChanged;
            panelList.Controls.Add(lstPatients);

            // ── Right panel – form ───────────────────────────────────
            panelForm = new Panel { Location = new Point(300, 55), Size = new Size(540, 480), BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle };

            int y = 15; int labelW = 120; int controlW = 350; int rowH = 38;
            Func<string, int, Label> lbl = (t, top) => new Label { Text = t, Location = new Point(10, top + 3), Size = new Size(labelW, 24), Font = new Font("Segoe UI", 10) };

            txtID      = new TextBox { Location = new Point(135, y), Size = new Size(200, 25), Font = new Font("Segoe UI", 10), ReadOnly = true, BackColor = Color.LightGray };
            panelForm.Controls.Add(lbl("Patient ID:", y)); panelForm.Controls.Add(txtID); y += rowH;

            txtName    = new TextBox { Location = new Point(135, y), Size = new Size(controlW, 25), Font = new Font("Segoe UI", 10) };
            panelForm.Controls.Add(lbl("Full Name:", y)); panelForm.Controls.Add(txtName); y += rowH;

            cboGender  = new ComboBox { Location = new Point(135, y), Size = new Size(150, 25), Font = new Font("Segoe UI", 10), DropDownStyle = ComboBoxStyle.DropDownList };
            cboGender.Items.AddRange(Enum.GetNames(typeof(Gender)));
            cboGender.SelectedIndex = 0;
            panelForm.Controls.Add(lbl("Gender:", y)); panelForm.Controls.Add(cboGender); y += rowH;

            dtpDOB     = new DateTimePicker { Location = new Point(135, y), Size = new Size(200, 25), Font = new Font("Segoe UI", 10), Format = DateTimePickerFormat.Short };
            dtpDOB.Value = DateTime.Today.AddYears(-25);
            panelForm.Controls.Add(lbl("Date of Birth:", y)); panelForm.Controls.Add(dtpDOB); y += rowH;

            txtPhone   = new TextBox { Location = new Point(135, y), Size = new Size(200, 25), Font = new Font("Segoe UI", 10) };
            panelForm.Controls.Add(lbl("Phone:", y)); panelForm.Controls.Add(txtPhone); y += rowH;

            cboBlood   = new ComboBox { Location = new Point(135, y), Size = new Size(150, 25), Font = new Font("Segoe UI", 10), DropDownStyle = ComboBoxStyle.DropDownList };
            cboBlood.Items.AddRange(Enum.GetNames(typeof(BloodType)));
            cboBlood.SelectedIndex = 0;
            panelForm.Controls.Add(lbl("Blood Type:", y)); panelForm.Controls.Add(cboBlood); y += rowH;

            txtAddress = new TextBox { Location = new Point(135, y), Size = new Size(controlW, 25), Font = new Font("Segoe UI", 10) };
            panelForm.Controls.Add(lbl("Address:", y)); panelForm.Controls.Add(txtAddress); y += rowH;

            txtAllergies = new TextBox { Location = new Point(135, y), Size = new Size(controlW, 25), Font = new Font("Segoe UI", 10) };
            panelForm.Controls.Add(lbl("Allergies:", y)); panelForm.Controls.Add(txtAllergies); y += rowH + 10;

            // Buttons inside form panel
            btnAdd = new Button
            {
                Text = "➕ Add Patient", Location = new Point(10, y), Size = new Size(150, 38),
                BackColor = Color.FromArgb(30, 130, 76), ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold), FlatStyle = FlatStyle.Flat
            };
            btnAdd.Click += BtnAdd_Click;

            btnRemove = new Button
            {
                Text = "🗑 Remove", Location = new Point(170, y), Size = new Size(120, 38),
                BackColor = Color.FromArgb(180, 40, 40), ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold), FlatStyle = FlatStyle.Flat
            };
            btnRemove.Click += BtnRemove_Click;

            btnDetails = new Button
            {
                Text = "🔍 Details", Location = new Point(300, y), Size = new Size(120, 38),
                BackColor = Color.FromArgb(30, 60, 100), ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold), FlatStyle = FlatStyle.Flat
            };
            btnDetails.Click += BtnDetails_Click;

            panelForm.Controls.AddRange(new Control[] { btnAdd, btnRemove, btnDetails });

            btnClose = new Button
            {
                Text = "Close", Location = new Point(740, 520), Size = new Size(90, 32),
                BackColor = Color.Gray, ForeColor = Color.White,
                Font = new Font("Segoe UI", 10), FlatStyle = FlatStyle.Flat
            };
            btnClose.Click += (s, e) => this.Close();

            this.Controls.AddRange(new Control[] { lblTitle, panelList, panelForm, btnClose });

            // Pre-fill ID
            txtID.Text = Clinic.Instance.GeneratePatientID();
        }

        private void LoadPatientList()
        {
            lstPatients.Items.Clear();
            foreach (var p in Clinic.Instance.GetAllPatients())
                lstPatients.Items.Add(p);
        }

        private void LstPatients_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstPatients.SelectedItem is Patient p)
            {
                txtID.Text         = p.ID;
                txtName.Text       = p.FullName;
                cboGender.SelectedIndex = (int)p.Gender;
                dtpDOB.Value       = p.DateOfBirth;
                txtPhone.Text      = p.Phone;
                cboBlood.SelectedIndex = (int)p.BloodType;
                txtAddress.Text    = p.Address;
                txtAllergies.Text  = p.Allergies;
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                // EXCEPTION HANDLING – validate required fields
                if (string.IsNullOrWhiteSpace(txtName.Text))
                    throw new ArgumentException("Patient name cannot be empty.");
                if (string.IsNullOrWhiteSpace(txtPhone.Text))
                    throw new ArgumentException("Phone number cannot be empty.");
                if (!System.Text.RegularExpressions.Regex.IsMatch(txtPhone.Text, @"^\d{10,15}$"))
                    throw new FormatException("Phone must be 10-15 digits.");

                var patient = new Patient(
                    id:          Clinic.Instance.GeneratePatientID(),
                    fullName:    txtName.Text.Trim(),
                    gender:      (Gender)cboGender.SelectedIndex,
                    dateOfBirth: dtpDOB.Value,
                    phone:       txtPhone.Text.Trim(),
                    bloodType:   (BloodType)cboBlood.SelectedIndex,
                    address:     txtAddress.Text.Trim(),
                    allergies:   txtAllergies.Text.Trim()
                );

                if (!Clinic.Instance.AddPatient(patient))
                    throw new InvalidOperationException("A patient with this ID already exists.");

                LoadPatientList();
                ClearForm();
                MessageBox.Show($"Patient {patient.FullName} registered successfully!", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (ArgumentException ex) { MessageBox.Show(ex.Message, "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            catch (FormatException   ex) { MessageBox.Show(ex.Message, "Format Error",     MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            catch (Exception         ex) { MessageBox.Show(ex.Message, "Error",            MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void BtnRemove_Click(object sender, EventArgs e)
        {
            if (lstPatients.SelectedItem is Patient p)
            {
                var confirm = MessageBox.Show($"Remove patient {p.FullName}?", "Confirm",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirm == DialogResult.Yes)
                {
                    Clinic.Instance.RemovePatient(p.ID);
                    LoadPatientList();
                    ClearForm();
                }
            }
            else MessageBox.Show("Please select a patient.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnDetails_Click(object sender, EventArgs e)
        {
            if (lstPatients.SelectedItem is Patient p)
                MessageBox.Show(p.GetDetails(), "Patient Details", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else MessageBox.Show("Please select a patient.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ClearForm()
        {
            txtID.Text = Clinic.Instance.GeneratePatientID();
            txtName.Text = txtPhone.Text = txtAddress.Text = txtAllergies.Text = "";
            cboGender.SelectedIndex = cboBlood.SelectedIndex = 0;
            dtpDOB.Value = DateTime.Today.AddYears(-25);
        }
    }
}

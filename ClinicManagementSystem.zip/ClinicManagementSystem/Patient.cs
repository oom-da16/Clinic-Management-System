using System;

namespace ClinicManagementSystem
{
    /// <summary>
    /// Represents a registered patient in the clinic.
    /// Inherits common personal information from Person.
    /// </summary>
    public class Patient : Person
    {
        // ── Patient-specific properties ──────────────────────────────
        public BloodType BloodType { get; set; }
        public string    Address   { get; set; }
        public string    Allergies { get; set; }

        // ── Constructor ─────────────────────────────────────────────
        public Patient(string id, string fullName, Gender gender,
                       DateTime dateOfBirth, string phone,
                       BloodType bloodType, string address, string allergies)
            : base(id, fullName, gender, dateOfBirth, phone)
        {
            BloodType = bloodType;
            Address   = address;
            Allergies = allergies;
        }

        // ── POLYMORPHISM – override abstract method ──────────────────
        public override string GetDetails()
        {
            return $"Patient ID   : {ID}\n" +
                   $"Name         : {FullName}\n" +
                   $"Age          : {Age} years\n" +
                   $"Gender       : {Gender}\n" +
                   $"Blood Type   : {BloodType}\n" +
                   $"Phone        : {Phone}\n" +
                   $"Address      : {Address}\n" +
                   $"Allergies    : {(string.IsNullOrEmpty(Allergies) ? "None" : Allergies)}";
        }

        // ── FILE HANDLING – serialise to CSV line ───────────────────
        public override string ToFileLine()
        {
            // Format: P|ID|FullName|Gender|DOB|Phone|BloodType|Address|Allergies
            return $"P|{ID}|{FullName}|{(int)Gender}|{DateOfBirth:yyyy-MM-dd}|" +
                   $"{Phone}|{(int)BloodType}|{Address}|{Allergies}";
        }

        // ── Deserialise from CSV line ────────────────────────────────
        public static Patient FromFileLine(string line)
        {
            // EXCEPTION HANDLING – wrapped at call site in FileManager
            string[] p = line.Split('|');
            return new Patient(
                id:          p[1],
                fullName:    p[2],
                gender:      (Gender)int.Parse(p[3]),
                dateOfBirth: DateTime.Parse(p[4]),
                phone:       p[5],
                bloodType:   (BloodType)int.Parse(p[6]),
                address:     p[7],
                allergies:   p[8]
            );
        }
    }
}

// ============================================================
//  File: FileManager.cs
//  Description: FILE HANDLING + EXCEPTION HANDLING
//               Saves and loads all clinic data as .txt files
// ============================================================

using System;
using System.Collections.Generic;
using System.IO;

namespace ClinicManagementSystem
{
    /// <summary>
    /// Static helper that reads/writes clinic data to text files.
    /// All I/O is wrapped in try/catch for robust EXCEPTION HANDLING.
    /// </summary>
    public static class FileManager
    {
        // ── File paths (relative to executable) ─────────────────────
        private static readonly string DataDir       = "ClinicData";
        private static readonly string PatientsFile  = Path.Combine(DataDir, "patients.txt");
        private static readonly string DoctorsFile   = Path.Combine(DataDir, "doctors.txt");
        private static readonly string AppointFile   = Path.Combine(DataDir, "appointments.txt");
        private static readonly string RecordsFile   = Path.Combine(DataDir, "records.txt");

        // ── Ensure data directory exists ─────────────────────────────
        static FileManager()
        {
            try { Directory.CreateDirectory(DataDir); }
            catch (Exception ex) { LogError("Cannot create data directory", ex); }
        }

        // ════════════════════════════════════════════════════════════
        //  PATIENTS
        // ════════════════════════════════════════════════════════════

        public static void SavePatients(Patient[] patients)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(PatientsFile, false))
                {
                    foreach (var p in patients)
                        if (p != null) writer.WriteLine(p.ToFileLine());
                }
            }
            catch (IOException ex)     { LogError("Failed to save patients",  ex); }
            catch (Exception   ex)     { LogError("Unexpected error saving patients", ex); }
        }

        public static List<Patient> LoadPatients()
        {
            List<Patient> list = new List<Patient>();
            if (!File.Exists(PatientsFile)) return list;
            try
            {
                string[] lines = File.ReadAllLines(PatientsFile);
                foreach (string line in lines)
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    try   { list.Add(Patient.FromFileLine(line)); }
                    catch (Exception ex) { LogError($"Corrupt patient line: {line}", ex); }
                }
            }
            catch (IOException ex) { LogError("Failed to load patients", ex); }
            return list;
        }

        // ════════════════════════════════════════════════════════════
        //  DOCTORS
        // ════════════════════════════════════════════════════════════

        public static void SaveDoctors(Doctor[] doctors)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(DoctorsFile, false))
                {
                    foreach (var d in doctors)
                        if (d != null) writer.WriteLine(d.ToFileLine());
                }
            }
            catch (IOException ex) { LogError("Failed to save doctors", ex); }
            catch (Exception   ex) { LogError("Unexpected error saving doctors", ex); }
        }

        public static List<Doctor> LoadDoctors()
        {
            List<Doctor> list = new List<Doctor>();
            if (!File.Exists(DoctorsFile)) return list;
            try
            {
                string[] lines = File.ReadAllLines(DoctorsFile);
                foreach (string line in lines)
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    try   { list.Add(Doctor.FromFileLine(line)); }
                    catch (Exception ex) { LogError($"Corrupt doctor line: {line}", ex); }
                }
            }
            catch (IOException ex) { LogError("Failed to load doctors", ex); }
            return list;
        }

        // ════════════════════════════════════════════════════════════
        //  APPOINTMENTS
        // ════════════════════════════════════════════════════════════

        public static void SaveAppointments(Appointment[] appointments)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(AppointFile, false))
                {
                    foreach (var a in appointments)
                        if (a != null) writer.WriteLine(a.ToFileLine());
                }
            }
            catch (IOException ex) { LogError("Failed to save appointments", ex); }
            catch (Exception   ex) { LogError("Unexpected error saving appointments", ex); }
        }

        public static List<Appointment> LoadAppointments()
        {
            List<Appointment> list = new List<Appointment>();
            if (!File.Exists(AppointFile)) return list;
            try
            {
                string[] lines = File.ReadAllLines(AppointFile);
                foreach (string line in lines)
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    try   { list.Add(Appointment.FromFileLine(line)); }
                    catch (Exception ex) { LogError($"Corrupt appointment line: {line}", ex); }
                }
            }
            catch (IOException ex) { LogError("Failed to load appointments", ex); }
            return list;
        }

        // ════════════════════════════════════════════════════════════
        //  MEDICAL RECORDS
        // ════════════════════════════════════════════════════════════

        public static void SaveRecords(MedicalRecord[] records)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(RecordsFile, false))
                {
                    foreach (var r in records)
                        if (r != null) writer.WriteLine(r.ToFileLine());
                }
            }
            catch (IOException ex) { LogError("Failed to save records", ex); }
            catch (Exception   ex) { LogError("Unexpected error saving records", ex); }
        }

        public static List<MedicalRecord> LoadRecords()
        {
            List<MedicalRecord> list = new List<MedicalRecord>();
            if (!File.Exists(RecordsFile)) return list;
            try
            {
                string[] lines = File.ReadAllLines(RecordsFile);
                foreach (string line in lines)
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    try   { list.Add(MedicalRecord.FromFileLine(line)); }
                    catch (Exception ex) { LogError($"Corrupt record line: {line}", ex); }
                }
            }
            catch (IOException ex) { LogError("Failed to load records", ex); }
            return list;
        }

        // ── Error logger ─────────────────────────────────────────────
        private static void LogError(string context, Exception ex)
        {
            try
            {
                string logPath = Path.Combine(DataDir, "error.log");
                File.AppendAllText(logPath,
                    $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {context}: {ex.Message}{Environment.NewLine}");
            }
            catch { /* silently swallow log errors */ }
        }
    }
}

// ============================================================
//  File: MedicalRecord.cs
//  Description: Links a visit to a diagnosis and prescription
// ============================================================

using System;

namespace ClinicManagementSystem
{
    /// <summary>
    /// Represents the medical outcome of a clinic visit.
    /// Attached to a completed Appointment.
    /// </summary>
    public class MedicalRecord
    {
        // ── Properties ──────────────────────────────────────────────
        public string   RecordID      { get; set; }
        public string   AppointmentID { get; set; }
        public string   PatientID     { get; set; }
        public string   DoctorID      { get; set; }
        public DateTime VisitDate     { get; set; }
        public string   Diagnosis     { get; set; }
        public string   Prescription  { get; set; }
        public string   FollowUpNotes { get; set; }

        // ── Constructor ─────────────────────────────────────────────
        public MedicalRecord(string recordID, string appointmentID,
                             string patientID, string doctorID,
                             DateTime visitDate, string diagnosis,
                             string prescription, string followUpNotes = "")
        {
            RecordID      = recordID;
            AppointmentID = appointmentID;
            PatientID     = patientID;
            DoctorID      = doctorID;
            VisitDate     = visitDate;
            Diagnosis     = diagnosis;
            Prescription  = prescription;
            FollowUpNotes = followUpNotes;
        }

        public string GetDetails()
        {
            return $"Record ID     : {RecordID}\n" +
                   $"Appointment   : {AppointmentID}\n" +
                   $"Patient ID    : {PatientID}\n" +
                   $"Doctor ID     : {DoctorID}\n" +
                   $"Visit Date    : {VisitDate:dd/MM/yyyy}\n" +
                   $"Diagnosis     : {Diagnosis}\n" +
                   $"Prescription  : {Prescription}\n" +
                   $"Follow-up     : {(string.IsNullOrEmpty(FollowUpNotes) ? "—" : FollowUpNotes)}";
        }

        public override string ToString()
            => $"{RecordID} | {VisitDate:dd/MM/yyyy} | {Diagnosis}";

        // ── FILE HANDLING ────────────────────────────────────────────
        public string ToFileLine()
        {
            // Replace pipe chars in text fields to avoid delimiter clash
            string safeRx  = Prescription.Replace("|", ";");
            string safeDx  = Diagnosis.Replace("|", ";");
            string safeNotes = FollowUpNotes.Replace("|", ";");
            return $"{RecordID}|{AppointmentID}|{PatientID}|{DoctorID}|" +
                   $"{VisitDate:yyyy-MM-dd}|{safeDx}|{safeRx}|{safeNotes}";
        }

        public static MedicalRecord FromFileLine(string line)
        {
            string[] p = line.Split('|');
            return new MedicalRecord(
                recordID:      p[0],
                appointmentID: p[1],
                patientID:     p[2],
                doctorID:      p[3],
                visitDate:     DateTime.Parse(p[4]),
                diagnosis:     p[5],
                prescription:  p[6],
                followUpNotes: p.Length > 7 ? p[7] : ""
            );
        }
    }
}

using System;
using System.Drawing;
using System.Windows.Forms;

namespace ClinicManagementSystem
{
    public class FormRecords : Form
    {
        private ListBox      lstRecords;
        private ComboBox     cboPatient;
        private TextBox      txtDiagnosis, txtPrescription, txtFollowUp;
        private Button       btnSave, btnView, btnClose;
        private Label        lblTitle, lblDetails;
        private Panel        panelForm, panelList;

        public FormRecords()
        {
            InitializeComponent();
            LoadPatientDropDown();
            LoadRecordList();
        }

        private void InitializeComponent()
        {
            this.Text            = "Medical Records";
            this.Size            = new Size(900, 600);
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox     = false;
            this.BackColor       = Color.WhiteSmoke;

            lblTitle = new Label
            {
                Text = "Medical Records", Font = new Font("Segoe UI", 16, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 60, 100), Location = new Point(10, 10), Size = new Size(400, 35)
            };

            panelList = new Panel { Location = new Point(10, 55), Size = new Size(300, 500) };
            lstRecords = new ListBox { Dock = DockStyle.Fill, Font = new Font("Consolas", 9), BackColor = Color.White };
            lstRecords.SelectedIndexChanged += Lst_SelectedIndexChanged;
            panelList.Controls.Add(lstRecords);

            panelForm = new Panel { Location = new Point(320, 55), Size = new Size(560, 500), BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle };

            int y = 15; int labelW = 130; int rowH = 42;
            Func<string, int, Label> lbl = (t, top) => new Label { Text = t, Location = new Point(10, top + 3), Size = new Size(labelW, 24), Font = new Font("Segoe UI", 10) };

            cboPatient = new ComboBox { Location = new Point(145, y), Size = new Size(390, 25), Font = new Font("Segoe UI", 10), DropDownStyle = ComboBoxStyle.DropDownList };
            cboPatient.SelectedIndexChanged += CboPatient_SelectedIndexChanged;
            panelForm.Controls.Add(lbl("Patient:", y)); panelForm.Controls.Add(cboPatient); y += rowH;

            txtDiagnosis = new TextBox { Location = new Point(145, y), Size = new Size(390, 70), Font = new Font("Segoe UI", 10), Multiline = true, ScrollBars = ScrollBars.Vertical };
            panelForm.Controls.Add(lbl("Diagnosis:", y)); panelForm.Controls.Add(txtDiagnosis); y += 80;

            txtPrescription = new TextBox { Location = new Point(145, y), Size = new Size(390, 70), Font = new Font("Segoe UI", 10), Multiline = true, ScrollBars = ScrollBars.Vertical };
            panelForm.Controls.Add(lbl("Prescription:", y)); panelForm.Controls.Add(txtPrescription); y += 80;

            txtFollowUp = new TextBox { Location = new Point(145, y), Size = new Size(390, 50), Font = new Font("Segoe UI", 10), Multiline = true };
            panelForm.Controls.Add(lbl("Follow-up:", y)); panelForm.Controls.Add(txtFollowUp); y += 60;

            lblDetails = new Label
            {
                Location = new Point(10, y), Size = new Size(530, 80),
                Font = new Font("Segoe UI", 9), ForeColor = Color.Gray,
                Text = "Select a patient above, fill in the diagnosis and prescription, then click Save Record."
            };
            panelForm.Controls.Add(lblDetails); y += 90;

            btnSave = new Button
            {
                Text = "💾 Save Record", Location = new Point(10, y), Size = new Size(160, 40),
                BackColor = Color.FromArgb(30, 130, 76), ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold), FlatStyle = FlatStyle.Flat
            };
            btnSave.Click += BtnSave_Click;

            btnView = new Button
            {
                Text = "🔍 View Record", Location = new Point(180, y), Size = new Size(160, 40),
                BackColor = Color.FromArgb(30, 60, 100), ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold), FlatStyle = FlatStyle.Flat
            };
            btnView.Click += BtnView_Click;

            panelForm.Controls.AddRange(new Control[] { btnSave, btnView });

            btnClose = new Button
            {
                Text = "Close", Location = new Point(780, 540), Size = new Size(90, 32),
                BackColor = Color.Gray, ForeColor = Color.White,
                Font = new Font("Segoe UI", 10), FlatStyle = FlatStyle.Flat
            };
            btnClose.Click += (s, e) => this.Close();

            this.Controls.AddRange(new Control[] { lblTitle, panelList, panelForm, btnClose });
        }

        private void LoadPatientDropDown()
        {
            cboPatient.Items.Clear();
            foreach (var p in Clinic.Instance.GetAllPatients()) cboPatient.Items.Add(p);
            if (cboPatient.Items.Count > 0) cboPatient.SelectedIndex = 0;
        }

        private void LoadRecordList()
        {
            lstRecords.Items.Clear();
            foreach (var r in Clinic.Instance.GetAllRecords())
            {
                var p = Clinic.Instance.FindPatientByID(r.PatientID);
                lstRecords.Items.Add($"{r.VisitDate:dd/MM/yy} | {p?.FullName ?? r.PatientID}");
            }
        }

        private void CboPatient_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboPatient.SelectedItem is Patient p)
            {
                var records = Clinic.Instance.GetRecordsForPatient(p.ID);
                lblDetails.Text = records.Length == 0
                    ? $"No previous records for {p.FullName}."
                    : $"{p.FullName} has {records.Length} existing record(s). Fill the form to add a new one.";
            }
        }

        private void Lst_SelectedIndexChanged(object sender, EventArgs e)
        {
            int idx = lstRecords.SelectedIndex;
            if (idx < 0) return;
            var records = Clinic.Instance.GetAllRecords();
            if (idx < records.Length)
            {
                var r = records[idx];
                txtDiagnosis.Text   = r.Diagnosis;
                txtPrescription.Text = r.Prescription;
                txtFollowUp.Text    = r.FollowUpNotes;
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (cboPatient.SelectedItem == null)             throw new ArgumentException("Please select a patient.");
                if (string.IsNullOrWhiteSpace(txtDiagnosis.Text)) throw new ArgumentException("Diagnosis cannot be empty.");
                if (string.IsNullOrWhiteSpace(txtPrescription.Text)) throw new ArgumentException("Prescription cannot be empty.");

                var patient = (Patient)cboPatient.SelectedItem;

                // Try to link to a completed appointment
                string apptID = "N/A";
                string doctorID = "N/A";
                var appts = Clinic.Instance.GetAppointmentsForPatient(patient.ID);
                foreach (var a in appts)
                    if (a.Status == AppointmentStatus.Completed || a.Status == AppointmentStatus.Confirmed)
                    { apptID = a.AppointmentID; doctorID = a.DoctorID; break; }

                var record = new MedicalRecord(
                    recordID:      Clinic.Instance.GenerateRecordID(),
                    appointmentID: apptID,
                    patientID:     patient.ID,
                    doctorID:      doctorID,
                    visitDate:     DateTime.Today,
                    diagnosis:     txtDiagnosis.Text.Trim(),
                    prescription:  txtPrescription.Text.Trim(),
                    followUpNotes: txtFollowUp.Text.Trim()
                );

                Clinic.Instance.AddRecord(record);
                LoadRecordList();
                txtDiagnosis.Clear(); txtPrescription.Clear(); txtFollowUp.Clear();
                MessageBox.Show("Medical record saved successfully!", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (ArgumentException ex) { MessageBox.Show(ex.Message, "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            catch (Exception         ex) { MessageBox.Show(ex.Message, "Error",            MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void BtnView_Click(object sender, EventArgs e)
        {
            int idx = lstRecords.SelectedIndex;
            if (idx < 0) { MessageBox.Show("Please select a record.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            var records = Clinic.Instance.GetAllRecords();
            if (idx < records.Length)
                MessageBox.Show(records[idx].GetDetails(), "Medical Record Details",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}

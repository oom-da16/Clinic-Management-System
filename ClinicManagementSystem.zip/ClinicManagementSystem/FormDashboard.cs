// ============================================================
//  File: FormDashboard.cs
//  Description: Main application window – navigation hub
// ============================================================

using System;
using System.Drawing;
using System.Windows.Forms;

namespace ClinicManagementSystem
{
    public class FormDashboard : Form
    {
        // ── Controls ─────────────────────────────────────────────────
        private Label     lblTitle, lblSubtitle, lblStats;
        private Button    btnPatients, btnDoctors, btnAppointments, btnRecords, btnExit;
        private Panel     panelSidebar, panelMain;

        public FormDashboard()
        {
            InitializeComponent();
            RefreshStats();
        }

        private void InitializeComponent()
        {
            this.Text            = "Clinic Management System – CSE015";
            this.Size            = new Size(900, 620);
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox     = false;
            this.BackColor       = Color.WhiteSmoke;

            // ── Sidebar ──────────────────────────────────────────────
            panelSidebar = new Panel
            {
                Dock      = DockStyle.Left,
                Width     = 220,
                BackColor = Color.FromArgb(30, 60, 100)
            };

            lblTitle = new Label
            {
                Text      = "🏥 Clinic\nManagement",
                ForeColor = Color.White,
                Font      = new Font("Segoe UI", 15, FontStyle.Bold),
                Location  = new Point(15, 25),
                Size      = new Size(190, 70),
                TextAlign = ContentAlignment.MiddleCenter
            };

            lblSubtitle = new Label
            {
                Text      = "CSE015 Spring 2026",
                ForeColor = Color.FromArgb(180, 210, 240),
                Font      = new Font("Segoe UI", 9),
                Location  = new Point(15, 95),
                Size      = new Size(190, 20),
                TextAlign = ContentAlignment.MiddleCenter
            };

            // Sidebar navigation buttons
            btnPatients     = MakeSidebarButton("👤  Patients",     new Point(10, 140));
            btnDoctors      = MakeSidebarButton("🩺  Doctors",      new Point(10, 195));
            btnAppointments = MakeSidebarButton("📅  Appointments", new Point(10, 250));
            btnRecords      = MakeSidebarButton("📋  Medical Records", new Point(10, 305));
            btnExit         = MakeSidebarButton("🚪  Exit",         new Point(10, 520));
            btnExit.BackColor = Color.FromArgb(180, 40, 40);

            panelSidebar.Controls.AddRange(new Control[]
                { lblTitle, lblSubtitle, btnPatients, btnDoctors,
                  btnAppointments, btnRecords, btnExit });

            // ── Main area ────────────────────────────────────────────
            panelMain = new Panel
            {
                Location  = new Point(220, 0),
                Size      = new Size(680, 590),
                BackColor = Color.WhiteSmoke
            };

            lblStats = new Label
            {
                Location  = new Point(20, 20),
                Size      = new Size(640, 540),
                Font      = new Font("Segoe UI", 13),
                ForeColor = Color.FromArgb(30, 60, 100)
            };

            panelMain.Controls.Add(lblStats);

            // ── Wire up ──────────────────────────────────────────────
            btnPatients    .Click += (s, e) => { new FormPatients().ShowDialog();     RefreshStats(); };
            btnDoctors     .Click += (s, e) => { new FormDoctors().ShowDialog();      RefreshStats(); };
            btnAppointments.Click += (s, e) => { new FormAppointments().ShowDialog(); RefreshStats(); };
            btnRecords     .Click += (s, e) => { new FormRecords().ShowDialog();      RefreshStats(); };
            btnExit        .Click += (s, e) => Application.Exit();

            this.Controls.AddRange(new Control[] { panelSidebar, panelMain });
        }

        private Button MakeSidebarButton(string text, Point location)
        {
            return new Button
            {
                Text      = text,
                Location  = location,
                Size      = new Size(200, 42),
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(50, 90, 140),
                ForeColor = Color.White,
                Font      = new Font("Segoe UI", 11),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding   = new Padding(10, 0, 0, 0),
                Cursor    = Cursors.Hand
            };
        }

        private void RefreshStats()
        {
            var clinic = Clinic.Instance;
            int patients     = clinic.GetAllPatients().Length;
            int doctors      = clinic.GetAllDoctors().Length;
            int appointments = clinic.GetAllAppointments().Length;
            int records      = clinic.GetAllRecords().Length;

            lblStats.Text =
                $"Welcome to the Clinic Management System\n" +
                $"{"─".PadRight(45, '─')}\n\n" +
                $"📊  System Overview\n\n" +
                $"   👤  Registered Patients      :  {patients}\n\n" +
                $"   🩺  Registered Doctors        :  {doctors}\n\n" +
                $"   📅  Total Appointments        :  {appointments}\n\n" +
                $"   📋  Medical Records           :  {records}\n\n\n" +
                $"{"─".PadRight(45, '─')}\n" +
                $"Select a module from the left panel to begin.";
        }
    }
}

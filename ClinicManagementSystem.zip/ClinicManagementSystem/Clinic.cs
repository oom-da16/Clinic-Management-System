// ============================================================
//  File: Clinic.cs
//  Description: Central data store using ARRAYS OF OBJECTS
//               and FILE HANDLING via FileManager
// ============================================================

using System;
using System.Linq;

namespace ClinicManagementSystem
{
    /// <summary>
    /// Holds all clinic data in fixed-size arrays and exposes
    /// CRUD operations. Demonstrates ARRAY OF OBJECTS concept.
    /// </summary>
    public class Clinic
    {
        // ── ARRAY OF OBJECTS ─────────────────────────────────────────
        private Patient[]       _patients;
        private Doctor[]        _doctors;
        private Appointment[]   _appointments;
        private MedicalRecord[] _records;

        private int _patientCount;
        private int _doctorCount;
        private int _appointmentCount;
        private int _recordCount;

        private const int MAX = 200;

        // ── Singleton-style instance ─────────────────────────────────
        public static Clinic Instance { get; } = new Clinic();

        private Clinic()
        {
            _patients     = new Patient[MAX];
            _doctors      = new Doctor[MAX];
            _appointments = new Appointment[MAX];
            _records      = new MedicalRecord[MAX];
            LoadAll();
        }

        // ════════════════════════════════════════════════════════════
        //  PATIENT CRUD
        // ════════════════════════════════════════════════════════════

        public bool AddPatient(Patient p)
        {
            if (_patientCount >= MAX) return false;
            if (FindPatientByID(p.ID) != null) return false;   // duplicate
            _patients[_patientCount++] = p;
            SaveAll();
            return true;
        }

        public Patient FindPatientByID(string id)
        {
            for (int i = 0; i < _patientCount; i++)
                if (_patients[i].ID.Equals(id, StringComparison.OrdinalIgnoreCase))
                    return _patients[i];
            return null;
        }

        public Patient[] GetAllPatients()
        {
            Patient[] result = new Patient[_patientCount];
            Array.Copy(_patients, result, _patientCount);
            return result;
        }

        public bool RemovePatient(string id)
        {
            for (int i = 0; i < _patientCount; i++)
            {
                if (_patients[i].ID.Equals(id, StringComparison.OrdinalIgnoreCase))
                {
                    // Shift left
                    for (int j = i; j < _patientCount - 1; j++)
                        _patients[j] = _patients[j + 1];
                    _patients[--_patientCount] = null;
                    SaveAll();
                    return true;
                }
            }
            return false;
        }

        // ════════════════════════════════════════════════════════════
        //  DOCTOR CRUD
        // ════════════════════════════════════════════════════════════

        public bool AddDoctor(Doctor d)
        {
            if (_doctorCount >= MAX) return false;
            if (FindDoctorByID(d.ID) != null) return false;
            _doctors[_doctorCount++] = d;
            SaveAll();
            return true;
        }

        public Doctor FindDoctorByID(string id)
        {
            for (int i = 0; i < _doctorCount; i++)
                if (_doctors[i].ID.Equals(id, StringComparison.OrdinalIgnoreCase))
                    return _doctors[i];
            return null;
        }

        public Doctor[] GetAllDoctors()
        {
            Doctor[] result = new Doctor[_doctorCount];
            Array.Copy(_doctors, result, _doctorCount);
            return result;
        }

        public bool RemoveDoctor(string id)
        {
            for (int i = 0; i < _doctorCount; i++)
            {
                if (_doctors[i].ID.Equals(id, StringComparison.OrdinalIgnoreCase))
                {
                    for (int j = i; j < _doctorCount - 1; j++)
                        _doctors[j] = _doctors[j + 1];
                    _doctors[--_doctorCount] = null;
                    SaveAll();
                    return true;
                }
            }
            return false;
        }

        // ════════════════════════════════════════════════════════════
        //  APPOINTMENT CRUD
        // ════════════════════════════════════════════════════════════

        public bool AddAppointment(Appointment a)
        {
            if (_appointmentCount >= MAX) return false;
            _appointments[_appointmentCount++] = a;
            SaveAll();
            return true;
        }

        public Appointment FindAppointmentByID(string id)
        {
            for (int i = 0; i < _appointmentCount; i++)
                if (_appointments[i].AppointmentID == id)
                    return _appointments[i];
            return null;
        }

        public Appointment[] GetAllAppointments()
        {
            Appointment[] result = new Appointment[_appointmentCount];
            Array.Copy(_appointments, result, _appointmentCount);
            return result;
        }

        public Appointment[] GetAppointmentsForPatient(string patientID)
        {
            return GetAllAppointments()
                .Where(a => a.PatientID == patientID).ToArray();
        }

        public void UpdateAppointmentStatus(string id, AppointmentStatus status)
        {
            var a = FindAppointmentByID(id);
            if (a != null) { a.Status = status; SaveAll(); }
        }

        // ════════════════════════════════════════════════════════════
        //  MEDICAL RECORDS CRUD
        // ════════════════════════════════════════════════════════════

        public bool AddRecord(MedicalRecord r)
        {
            if (_recordCount >= MAX) return false;
            _records[_recordCount++] = r;
            SaveAll();
            return true;
        }

        public MedicalRecord[] GetRecordsForPatient(string patientID)
        {
            return GetAllRecords().Where(r => r.PatientID == patientID).ToArray();
        }

        public MedicalRecord[] GetAllRecords()
        {
            MedicalRecord[] result = new MedicalRecord[_recordCount];
            Array.Copy(_records, result, _recordCount);
            return result;
        }

        // ════════════════════════════════════════════════════════════
        //  ID GENERATORS
        // ════════════════════════════════════════════════════════════

        public string GeneratePatientID()     => $"P{(1000 + _patientCount):D4}";
        public string GenerateDoctorID()      => $"D{(100  + _doctorCount):D3}";
        public string GenerateAppointmentID() => $"A{DateTime.Now:yyyyMMddHHmmss}";
        public string GenerateRecordID()      => $"R{(1000 + _recordCount):D4}";

        // ════════════════════════════════════════════════════════════
        //  FILE HANDLING – delegate to FileManager
        // ════════════════════════════════════════════════════════════

        public void SaveAll()
        {
            FileManager.SavePatients(GetAllPatients());
            FileManager.SaveDoctors(GetAllDoctors());
            FileManager.SaveAppointments(GetAllAppointments());
            FileManager.SaveRecords(GetAllRecords());
        }

        private void LoadAll()
        {
            // EXCEPTION HANDLING inside FileManager
            var patients = FileManager.LoadPatients();
            foreach (var p in patients) if (_patientCount < MAX) _patients[_patientCount++] = p;

            var doctors = FileManager.LoadDoctors();
            foreach (var d in doctors) if (_doctorCount < MAX) _doctors[_doctorCount++] = d;

            var appointments = FileManager.LoadAppointments();
            foreach (var a in appointments) if (_appointmentCount < MAX) _appointments[_appointmentCount++] = a;

            var records = FileManager.LoadRecords();
            foreach (var r in records) if (_recordCount < MAX) _records[_recordCount++] = r;
        }
    }
}

// ============================================================
//  File: FormDoctors.cs
//  Description: Doctor registration and management UI
// ============================================================

using System;
using System.Drawing;
using System.Windows.Forms;

namespace ClinicManagementSystem
{
    public class FormDoctors : Form
    {
        private ListBox      lstDoctors;
        private TextBox      txtID, txtName, txtPhone, txtLicense, txtDays, txtFee;
        private ComboBox     cboGender, cboSpec;
        private DateTimePicker dtpDOB;
        private Button       btnAdd, btnRemove, btnDetails, btnClose;
        private Label        lblTitle;
        private Panel        panelForm, panelList;

        public FormDoctors()
        {
            InitializeComponent();
            LoadDoctorList();
        }

        private void InitializeComponent()
        {
            this.Text            = "Doctor Management";
            this.Size            = new Size(860, 600);
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox     = false;
            this.BackColor       = Color.WhiteSmoke;

            lblTitle = new Label
            {
                Text      = "Doctor Registration",
                Font      = new Font("Segoe UI", 16, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 60, 100),
                Location  = new Point(10, 10),
                Size      = new Size(400, 35)
            };

            panelList = new Panel { Location = new Point(10, 55), Size = new Size(280, 500) };
            lstDoctors = new ListBox { Dock = DockStyle.Fill, Font = new Font("Consolas", 10), BackColor = Color.White };
            lstDoctors.SelectedIndexChanged += LstDoctors_SelectedIndexChanged;
            panelList.Controls.Add(lstDoctors);

            panelForm = new Panel { Location = new Point(300, 55), Size = new Size(540, 500), BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle };

            int y = 15; int labelW = 130; int controlW = 360; int rowH = 38;
            Func<string, int, Label> lbl = (t, top) => new Label { Text = t, Location = new Point(10, top + 3), Size = new Size(labelW, 24), Font = new Font("Segoe UI", 10) };

            txtID = new TextBox { Location = new Point(145, y), Size = new Size(180, 25), Font = new Font("Segoe UI", 10), ReadOnly = true, BackColor = Color.LightGray };
            panelForm.Controls.Add(lbl("Doctor ID:", y)); panelForm.Controls.Add(txtID); y += rowH;

            txtName = new TextBox { Location = new Point(145, y), Size = new Size(controlW, 25), Font = new Font("Segoe UI", 10) };
            panelForm.Controls.Add(lbl("Full Name:", y)); panelForm.Controls.Add(txtName); y += rowH;

            cboGender = new ComboBox { Location = new Point(145, y), Size = new Size(150, 25), Font = new Font("Segoe UI", 10), DropDownStyle = ComboBoxStyle.DropDownList };
            cboGender.Items.AddRange(Enum.GetNames(typeof(Gender)));
            cboGender.SelectedIndex = 0;
            panelForm.Controls.Add(lbl("Gender:", y)); panelForm.Controls.Add(cboGender); y += rowH;

            dtpDOB = new DateTimePicker { Location = new Point(145, y), Size = new Size(180, 25), Font = new Font("Segoe UI", 10), Format = DateTimePickerFormat.Short };
            dtpDOB.Value = DateTime.Today.AddYears(-35);
            panelForm.Controls.Add(lbl("Date of Birth:", y)); panelForm.Controls.Add(dtpDOB); y += rowH;

            txtPhone = new TextBox { Location = new Point(145, y), Size = new Size(200, 25), Font = new Font("Segoe UI", 10) };
            panelForm.Controls.Add(lbl("Phone:", y)); panelForm.Controls.Add(txtPhone); y += rowH;

            cboSpec = new ComboBox { Location = new Point(145, y), Size = new Size(230, 25), Font = new Font("Segoe UI", 10), DropDownStyle = ComboBoxStyle.DropDownList };
            cboSpec.Items.AddRange(Enum.GetNames(typeof(Specialization)));
            cboSpec.SelectedIndex = 0;
            panelForm.Controls.Add(lbl("Specialization:", y)); panelForm.Controls.Add(cboSpec); y += rowH;

            txtLicense = new TextBox { Location = new Point(145, y), Size = new Size(200, 25), Font = new Font("Segoe UI", 10) };
            panelForm.Controls.Add(lbl("License No.:", y)); panelForm.Controls.Add(txtLicense); y += rowH;

            txtDays = new TextBox { Location = new Point(145, y), Size = new Size(controlW, 25), Font = new Font("Segoe UI", 10), PlaceholderText = "e.g. Sun,Mon,Tue" };
            panelForm.Controls.Add(lbl("Working Days:", y)); panelForm.Controls.Add(txtDays); y += rowH;

            txtFee = new TextBox { Location = new Point(145, y), Size = new Size(120, 25), Font = new Font("Segoe UI", 10), Text = "100" };
            panelForm.Controls.Add(lbl("Consult. Fee:", y)); panelForm.Controls.Add(txtFee); y += rowH + 10;

            btnAdd = new Button
            {
                Text = "➕ Add Doctor", Location = new Point(10, y), Size = new Size(150, 38),
                BackColor = Color.FromArgb(30, 130, 76), ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold), FlatStyle = FlatStyle.Flat
            };
            btnAdd.Click += BtnAdd_Click;

            btnRemove = new Button
            {
                Text = "🗑 Remove", Location = new Point(170, y), Size = new Size(120, 38),
                BackColor = Color.FromArgb(180, 40, 40), ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold), FlatStyle = FlatStyle.Flat
            };
            btnRemove.Click += BtnRemove_Click;

            btnDetails = new Button
            {
                Text = "🔍 Details", Location = new Point(300, y), Size = new Size(120, 38),
                BackColor = Color.FromArgb(30, 60, 100), ForeColor = Color.White,
                Font = new Font("Segoe UI", 10, FontStyle.Bold), FlatStyle = FlatStyle.Flat
            };
            btnDetails.Click += BtnDetails_Click;

            panelForm.Controls.AddRange(new Control[] { btnAdd, btnRemove, btnDetails });

            btnClose = new Button
            {
                Text = "Close", Location = new Point(740, 540), Size = new Size(90, 32),
                BackColor = Color.Gray, ForeColor = Color.White,
                Font = new Font("Segoe UI", 10), FlatStyle = FlatStyle.Flat
            };
            btnClose.Click += (s, e) => this.Close();

            this.Controls.AddRange(new Control[] { lblTitle, panelList, panelForm, btnClose });
            txtID.Text = Clinic.Instance.GenerateDoctorID();
        }

        private void LoadDoctorList()
        {
            lstDoctors.Items.Clear();
            foreach (var d in Clinic.Instance.GetAllDoctors())
                lstDoctors.Items.Add(d);
        }

        private void LstDoctors_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstDoctors.SelectedItem is Doctor d)
            {
                txtID.Text = d.ID; txtName.Text = d.FullName;
                cboGender.SelectedIndex = (int)d.Gender;
                dtpDOB.Value = d.DateOfBirth;
                txtPhone.Text = d.Phone;
                cboSpec.SelectedIndex = (int)d.Specialization;
                txtLicense.Text = d.LicenseNumber;
                txtDays.Text = d.WorkingDays;
                txtFee.Text = d.ConsultationFee.ToString();
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtName.Text))   throw new ArgumentException("Doctor name is required.");
                if (string.IsNullOrWhiteSpace(txtLicense.Text)) throw new ArgumentException("License number is required.");
                if (!decimal.TryParse(txtFee.Text, out decimal fee) || fee < 0)
                    throw new FormatException("Consultation fee must be a positive number.");

                var doctor = new Doctor(
                    id:             Clinic.Instance.GenerateDoctorID(),
                    fullName:       txtName.Text.Trim(),
                    gender:         (Gender)cboGender.SelectedIndex,
                    dateOfBirth:    dtpDOB.Value,
                    phone:          txtPhone.Text.Trim(),
                    specialization: (Specialization)cboSpec.SelectedIndex,
                    licenseNumber:  txtLicense.Text.Trim(),
                    workingDays:    txtDays.Text.Trim(),
                    consultationFee: fee
                );

                if (!Clinic.Instance.AddDoctor(doctor))
                    throw new InvalidOperationException("A doctor with this ID already exists.");

                LoadDoctorList();
                ClearForm();
                MessageBox.Show($"Dr. {doctor.FullName} registered successfully!", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (ArgumentException ex) { MessageBox.Show(ex.Message, "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            catch (FormatException   ex) { MessageBox.Show(ex.Message, "Format Error",     MessageBoxButtons.OK, MessageBoxIcon.Warning); }
            catch (Exception         ex) { MessageBox.Show(ex.Message, "Error",            MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void BtnRemove_Click(object sender, EventArgs e)
        {
            if (lstDoctors.SelectedItem is Doctor d)
            {
                if (MessageBox.Show($"Remove Dr. {d.FullName}?", "Confirm",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                { Clinic.Instance.RemoveDoctor(d.ID); LoadDoctorList(); ClearForm(); }
            }
            else MessageBox.Show("Please select a doctor.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnDetails_Click(object sender, EventArgs e)
        {
            if (lstDoctors.SelectedItem is Doctor d)
                MessageBox.Show(d.GetDetails(), "Doctor Details", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else MessageBox.Show("Please select a doctor.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ClearForm()
        {
            txtID.Text = Clinic.Instance.GenerateDoctorID();
            txtName.Text = txtPhone.Text = txtLicense.Text = txtDays.Text = "";
            txtFee.Text = "100";
            cboGender.SelectedIndex = cboSpec.SelectedIndex = 0;
            dtpDOB.Value = DateTime.Today.AddYears(-35);
        }
    }
}

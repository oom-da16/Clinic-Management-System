using System;

namespace ClinicManagementSystem
{
    /// <summary>
    /// Abstract base class for all people in the clinic system.
    /// Doctor and Patient both inherit from this class.
    /// </summary>
    public abstract class Person
    {
        // ── Properties ──────────────────────────────────────────────
        public string ID       { get; set; }
        public string FullName { get; set; }
        public Gender Gender   { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Phone    { get; set; }

        // ── Computed ────────────────────────────────────────────────
        public int Age => (DateTime.Today - DateOfBirth).Days / 365;

        // ── Constructor ─────────────────────────────────────────────
        protected Person(string id, string fullName, Gender gender,
                         DateTime dateOfBirth, string phone)
        {
            ID          = id;
            FullName    = fullName;
            Gender      = gender;
            DateOfBirth = dateOfBirth;
            Phone       = phone;
        }

        // ── Abstract method – overridden by subclasses (POLYMORPHISM) ──
        public abstract string GetDetails();

        // ── Override ToString ────────────────────────────────────────
        public override string ToString() => $"{ID} | {FullName} | {Age} yrs";

        // ── Serialise to one line of text (FILE HANDLING) ───────────
        public abstract string ToFileLine();
    }
}

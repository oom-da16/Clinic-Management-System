// ============================================================
//  CSE015 – Object-Oriented Programming  |  Spring 2026
//  Clinic Management System
//  File: Enums.cs
//  Description: All project-wide enumerations
// ============================================================

namespace ClinicManagementSystem
{
    /// <summary>
    /// Represents the current status of a scheduled appointment.
    /// </summary>
    public enum AppointmentStatus
    {
        Pending,
        Confirmed,
        Cancelled,
        Completed
    }

    /// <summary>
    /// Biological gender of a person.
    /// </summary>
    public enum Gender
    {
        Male,
        Female
    }

    /// <summary>
    /// Standard ABO blood-type classification.
    /// </summary>
    public enum BloodType
    {
        APositive,
        ANegative,
        BPositive,
        BNegative,
        ABPositive,
        ABNegative,
        OPositive,
        ONegative,
        Unknown
    }

    /// <summary>
    /// Medical specializations available in the clinic.
    /// </summary>
    public enum Specialization
    {
        GeneralPractice,
        Cardiology,
        Dermatology,
        Pediatrics,
        Orthopedics,
        Neurology,
        Gynecology,
        ENT
    }
}
